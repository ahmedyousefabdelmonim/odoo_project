# -*- coding: utf-8 -*-
from odoo import http

# class Abdelambod(http.Controller):
#     @http.route('/abdelambod/abdelambod/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/abdelambod/abdelambod/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('abdelambod.listing', {
#             'root': '/abdelambod/abdelambod',
#             'objects': http.request.env['abdelambod.abdelambod'].search([]),
#         })

#     @http.route('/abdelambod/abdelambod/objects/<model("abdelambod.abdelambod"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('abdelambod.object', {
#             'object': obj
#         })
# -*- coding: utf-8 -*-


from odoo.exceptions import UserError
from odoo import models, fields, api ,_


class district(models.Model):
    _name = 'district.district'
    _rec_name = 'name'

    name = fields.Char(string="District" ,required=True)
    code = fields.Char(string="Code" , readonly=True)
    sector = fields.Many2one(comodel_name='sector.sector' , string="Sector")
    zone = fields.Many2one(comodel_name='zone.zone' , string="Zone" )
    temp = fields.Boolean(default=False)

    commissary_count = fields.Integer(compute='get_commissary_count')

    @api.depends('commissary_count')
    def get_commissary_count(self):
        commissary = self.env['commissary.commissary'].search([('district' , '=' , self.id)])
        self.commissary_count = len(commissary)


    @api.onchange('sector')
    def onchange_sector(self):
        if self.name:
            return {'domain': {'zone': [('sector', '=', self.sector.id)]}}
    @api.onchange('zone')
    def onchange_zone(self):
        if self.name:
            if not self.sector:
                raise UserError("Please Choose The Sector First Then The Zone .")


    @api.multi
    def district_action_view_commissary(self):
        self.ensure_one()
        domain = [('district', '=', self.id)]
        return {
            'name': _('District'),
            'domain': domain,
            'res_model': 'commissary.commissary',
            'type': 'ir.actions.act_window',
            'view_id': False,
            'view_mode': 'tree,form',
            'view_type': 'form',
            'limit': 80,
        }






    @api.model
    def create(self, vals):
        vals['temp'] = True
        zone = self.env['zone.zone'].search([('id' , '=' , vals['zone'])]).code
        sector = self.env['sector.sector'].search([('id' , '=' , vals['sector'])]).code
        if zone:
            vals['code'] = zone + self.env['ir.sequence'].next_by_code('district.district.seq')
        elif sector:
            vals['code'] = sector + self.env['ir.sequence'].next_by_code('district.district.seq')
        else:
            vals['code'] = self.env['ir.sequence'].next_by_code('district.district.seq')
        return super(district, self).create(vals)
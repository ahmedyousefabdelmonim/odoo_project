# -*- coding: utf-8 -*-

from odoo import models, fields, api ,_


class sector(models.Model):
    _name = 'sector.sector'
    _rec_name = 'name'

    _sql_constraints = [
        ('name_uniq', 'UNIQUE (name)', 'You can not have two Sectors with the same name !')
    ]

    name = fields.Char(string="Sector" , required=True)
    code = fields.Char(string="Code" , readonly=True)
    temp = fields.Boolean(default=False)
    zones_count = fields.Integer(compute='get_zones_count')
    district_count = fields.Integer(compute='get_district_count')
    commissary_count = fields.Integer(compute='get_commissary_count')

    @api.depends('commissary_count')
    def get_commissary_count(self):
        commissary = self.env['commissary.commissary'].search([('sector' , '=' , self.id)])
        self.commissary_count = len(commissary)

    @api.depends('zones_count')
    def get_zones_count(self):
        zone = self.env['zone.zone'].search([('sector' , '=' , self.id)])
        self.zones_count = len(zone)

    @api.depends('district_count')
    def get_district_count(self):
        district = self.env['district.district'].search([('sector', '=', self.id)])
        self.district_count = len(district)


    @api.multi
    def sector_action_view_zones(self):
        self.ensure_one()
        domain = [('sector', '=', self.id)]
        return {
            'name': _('Zones'),
            'domain': domain,
            'res_model': 'zone.zone',
            'type': 'ir.actions.act_window',
            'view_id': False,
            'view_mode': 'tree,form',
            'view_type': 'form',
            'limit': 80,
        }


    @api.multi
    def sector_action_view_district(self):
        self.ensure_one()
        domain = [('sector', '=', self.id)]
        return {
            'name': _('District'),
            'domain': domain,
            'res_model': 'district.district',
            'type': 'ir.actions.act_window',
            'view_id': False,
            'view_mode': 'tree,form',
            'view_type': 'form',
            'limit': 80,
        }
    @api.multi
    def sector_action_view_commissary(self):
        self.ensure_one()
        domain = [('sector', '=', self.id)]
        return {
            'name': _('District'),
            'domain': domain,
            'res_model': 'commissary.commissary',
            'type': 'ir.actions.act_window',
            'view_id': False,
            'view_mode': 'tree,form',
            'view_type': 'form',
            'limit': 80,
        }




    @api.model
    def create(self, vals):
        vals['temp'] = True
        vals['code'] = self.env['ir.sequence'].next_by_code('sector.sector.seq')
        return super(sector, self).create(vals)

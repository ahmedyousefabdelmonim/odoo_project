# -*- coding: utf-8 -*-

from odoo import models, fields, api ,_
from odoo.exceptions import UserError



class location_inherit(models.Model):
    _inherit = 'stock.location'

    commiassary = fields.Many2one(comodel_name='commissary.commissary' , string="Commiassary")

    loc_address = fields.Char(string="Location Address",)
    code = fields.Char('Code', required=False, help="Short name used to identify your location" , readonly=True)
    location_type = fields.Selection([('main', 'Main'), ('sub', 'Sub')], string="Location Type" , compute='get_loc')

    @api.one
    @api.depends('location_id')
    def get_loc(self):
        if self.location_id:
            self.update({'location_type' : "sub" })
        else:
            self.update({'location_type' : "main" })



    @api.model
    def create(self, vals):
        # print(vals['location_id']  ,"vals['location_type'] vals['location_type'] ")
        # code_seq = self.env['stock.location'].search([('id' , '=' , vals['location_id'])]).code + self.env['ir.sequence'].next_by_code('stock.location.seq.sub')
        var1 = self.env['stock.location'].search([('id' , '=' , vals['location_id'])]).code
        if not vals['location_id']:
            vals['code'] = self.env['ir.sequence'].next_by_code('stock.location.seq.main')
        else:
            # print( "QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ")
            # print(code_seq , "HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH")
            if var1:
                vals['code'] = str(self.env['stock.location'].search([('id' , '=' , vals['location_id'])]).code) + self.env['ir.sequence'].next_by_code('stock.location.seq.sub')
            else:
                vals['code'] = self.env['ir.sequence'].next_by_code('stock.location.seq.sub')

        return super(location_inherit, self).create(vals)

# -*- coding: utf-8 -*-

from odoo import models, fields, api ,_
from odoo.exceptions import UserError



class commissary(models.Model):
    _name = 'commissary.commissary'
    _rec_name = 'name'

    name = fields.Char(string="Commissary" , required=True)
    code = fields.Char(string="Code" , readonly=True)
    temp = fields.Boolean(default=False)
    sector = fields.Many2one(comodel_name='sector.sector' , string="Sector")
    zone = fields.Many2one(comodel_name='zone.zone' , string="Zone" )
    district = fields.Many2one(comodel_name='district.district' , string="District" )
    active = fields.Boolean('Active', default=True)
    user_id = fields.Many2one(comodel_name='res.users', string='User', readonly=True)
    warehouse = fields.Many2one(comodel_name='stock.warehouse', string='Warehouse')
    location = fields.Many2one(comodel_name='stock.location', string='Location')


    # @api.onchange('location' , 'id')
    # def onchange_location(self):
    #     com = self.env.context.get('active_id')
    #     print(com , self.id , "CCCCCCCCCCCCCCCOOOOOOOOOOOOOOOOOOOOOMMMMMMMMMMMMMMMMMM")
    #     self.location.commiassary.write({'commiassary' : com})



    @api.onchange('sector')
    def onchange_sector(self):
        if self.name:
            return {'domain': {'zone': [('sector', '=', self.sector.id)]}}



    @api.onchange('zone' )
    def onchange_zone(self):
        if self.name:
            if not self.sector:
                raise UserError("Please Choose The Sector First Then The Zone .")
            else:
                return {'domain': {'district': [('zone', '=', self.zone.id),('sector', '=', self.sector.id)]}}

    @api.onchange('district' )
    def onchange_district(self):
        if self.name:
            if not self.sector:
                raise UserError("Please Choose The Sector First Then The Zone .")
            elif not self.zone:
                raise UserError("Please Choose The Zone First Then The District .")



    @api.model
    def create(self, vals):
        vals['temp'] = True
        zone = self.env['zone.zone'].search([('id' , '=' , vals['zone'])]).code
        sector = self.env['sector.sector'].search([('id' , '=' , vals['sector'])]).code
        district = self.env['district.district'].search([('id' , '=' , vals['district'])]).code
        vals['user_id'] = self.env['res.users'].create({'name': vals['name'],
                                             'login': vals['name']+'@example.com',
                                             }).id
        if district:
            vals['code'] = district + self.env['ir.sequence'].next_by_code('commissary.commissary.seq')
        elif zone:
            vals['code'] = zone + self.env['ir.sequence'].next_by_code('commissary.commissary.seq')
        elif sector:
            vals['code'] = sector + self.env['ir.sequence'].next_by_code('commissary.commissary.seq')
        else:
            vals['code'] = self.env['ir.sequence'].next_by_code('commissary.commissary.seq')


        return super(commissary, self).create(vals)


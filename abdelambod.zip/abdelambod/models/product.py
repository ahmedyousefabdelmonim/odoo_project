# -*- coding: utf-8 -*-

from odoo import models, fields, api ,_

# class abdelambod(models.Model):
#     _name = 'abdelambod.abdelambod'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         self.value2 = float(self.value) / 100


class product_package_type(models.Model):
    _name = 'product.package_type'
    _rec_name = 'name'

    name = fields.Char(string="Name")


class product_product_type(models.Model):
    _name = 'product.product_type'
    _rec_name = 'name'

    name = fields.Char(string="Name")


class product_roast(models.Model):
    _name = 'product.roast'
    _rec_name = 'name'

    name = fields.Char(string="Name")



class product_template_inherit(models.Model):
    _inherit = 'product.template'

    _sql_constraints = [('product_template_num_unique', 'unique(product_num)', 'Product Num Already Exist.')]


    cartoon = fields.Boolean(string='Cartoon', default=False)
    package_type =fields.Many2one(comodel_name='product.package_type' , string="Package Type" , required=False)
    product_type =fields.Many2one(comodel_name='product.product_type' , string="Type" , required=False)
    roast = fields.Many2one(comodel_name='product.roast' , string="Roast" , required=False)
    vendor_id = fields.Many2one('res.partner', 'Vendor', domain="[('supplier','=',True)]")
    KgPerCartoon = fields.Integer(string='KgPerCartoon', )
    pro_per_cartoon = fields.Integer(string='Product Per Cartoon', compute='get_numberof_units')
    cartoon_products = fields.Many2one('product.template', 'Cartoon Of Product', domain="[('cartoon','=',False)]")
    g_kg = fields.Selection(selection=[('kg','KG'),('g','G')] , default="kg")
    @api.one
    @api.depends('KgPerCartoon','cartoon_products')
    def get_numberof_units(self):
        weight_pro = self.cartoon_products.weight
        units = 0
        if weight_pro != 0:
            if self.cartoon_products.g_kg == "kg":
                units = self.KgPerCartoon / weight_pro
            elif self.cartoon_products.g_kg == "g":
                units = self.KgPerCartoon / (weight_pro/1000)
        self.update({'pro_per_cartoon' : units})

    def _default_product_num(self):
        count = 1
        for pro in self.env['product.template'].search([('cartoon' , '=' , False )]):
            count +=1

        return count

    product_num = fields.Integer(string="Product Number" , default=_default_product_num , readonly=True)

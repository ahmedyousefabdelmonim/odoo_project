# -*- coding: utf-8 -*-

from odoo import models, fields, api ,_


class zone(models.Model):
    _name = 'zone.zone'
    _rec_name = 'name'



    name = fields.Char(string="Zone" , required=True)
    code = fields.Char(string="Code" , readonly=True)
    sector = fields.Many2one(comodel_name='sector.sector' , string="Sector")
    temp = fields.Boolean(default=False)

    district_count = fields.Integer(compute='get_district_count')

    commissary_count = fields.Integer(compute='get_commissary_count')

    @api.depends('commissary_count')
    def get_commissary_count(self):
        commissary = self.env['commissary.commissary'].search([('zone' , '=' , self.id)])
        self.commissary_count = len(commissary)


    @api.depends('district_count')
    def get_district_count(self):
        district = self.env['district.district'].search([('zone', '=', self.id)])
        self.district_count = len(district)


    @api.multi
    def zone_action_view_district(self):
        self.ensure_one()
        domain = [('zone', '=', self.id)]
        return {
            'name': _('District'),
            'domain': domain,
            'res_model': 'district.district',
            'type': 'ir.actions.act_window',
            'view_id': False,
            'view_mode': 'tree,form',
            'view_type': 'form',
            'limit': 80,
        }

    @api.multi
    def zone_action_view_commissary(self):
        self.ensure_one()
        domain = [('zone', '=', self.id)]
        return {
            'name': _('District'),
            'domain': domain,
            'res_model': 'commissary.commissary',
            'type': 'ir.actions.act_window',
            'view_id': False,
            'view_mode': 'tree,form',
            'view_type': 'form',
            'limit': 80,
        }




    @api.model
    def create(self, vals):
        vals['temp'] = True
        sector = self.env['sector.sector'].search([('id' , '=' , vals['sector'])]).code
        if sector:
            vals['code'] = sector + self.env['ir.sequence'].next_by_code('zone.zone.seq')
        else:
            vals['code'] = self.env['ir.sequence'].next_by_code('zone.zone.seq')

        return super(zone, self).create(vals)


# -*- coding: utf-8 -*-

from odoo import models, fields, api ,_
from odoo.exceptions import UserError


class account_analytic_inherit(models.Model):
    _inherit = 'account.analytic.account'

    user_id = fields.Many2many(comodel_name='res.users', string='User')


class payment_terms_inherit(models.Model):
    _inherit = 'account.payment.term'

    user_id = fields.Many2many(comodel_name='res.users', string='User')


class acc_journal_inherit(models.Model):
    _inherit = 'account.journal'

    user_id = fields.Many2many(comodel_name='res.users', string='User')


class stock_warehouse_inherit(models.Model):
    _inherit = 'stock.warehouse'

    user_id = fields.Many2many(comodel_name='res.users', string='User')


class stock_loc_inherit(models.Model):
    _inherit = 'stock.location'

    user_id = fields.Many2many(comodel_name='res.users', string='User')


class partner_template_inherit(models.Model):
    _inherit = 'product.pricelist'

    user_id = fields.Many2many(comodel_name='res.users', string='User')


# class partner_template_inherit(models.Model):
#     _inherit = 'product.pricelist'


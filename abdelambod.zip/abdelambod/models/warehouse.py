# -*- coding: utf-8 -*-

from odoo import models, fields, api ,_
from odoo.exceptions import UserError




class warehouse_picking_inherit(models.Model):
    _inherit = 'stock.picking'

    sector = fields.Many2one(comodel_name='sector.sector' , string="Sector")
    commissary = fields.Many2one(comodel_name='commissary.commissary' , string="Commissary")



    @api.multi
    @api.onchange('location_dest_id')
    def onchange_dest_loc(self):
        self.update({'commissary' : self.location_dest_id.commiassary.id ,
                     'sector': self.location_dest_id.commiassary.sector.id,})
        # self.update({'sector' : self.location_dest_id.commiassary.sector.id ,})


class warehouse_inherit(models.Model):
    _inherit = 'stock.warehouse'

    #
    # currency_id = fields.Many2one('res.currency', string='Currency', required=True, default=lambda self: self.env.user.company_id.currency_id)
    # code = fields.Char(string="Number", readonly=True)
    # customer_state =fields.Many2one(comodel_name='customer.state_mod' , string="Customer State" , required=False)
    code = fields.Char('Short Name', required=False, size=5, help="Short name used to identify your warehouse" , readonly=True)
    loc_address = fields.Char(string="Location Address",)



    @api.model
    def create(self, vals):
        # create view location for warehouse then create all locations

        loc_vals = {'name': _(vals.get('code')), 'usage': 'view',
                    'location_id': self.env.ref('stock.stock_location_locations').id}
        if vals.get('company_id'):
            loc_vals['company_id'] = vals.get('company_id')
        vals['view_location_id'] = self.env['stock.location'].create(loc_vals).id
        vals['code'] = self.env['ir.sequence'].next_by_code('stock.warehouse.seq')

        def_values = self.default_get(['reception_steps', 'delivery_steps'])
        reception_steps = vals.get('reception_steps',  def_values['reception_steps'])
        delivery_steps = vals.get('delivery_steps', def_values['delivery_steps'])
        sub_locations = {
            'lot_stock_id': {'name': _('Stock'), 'active': True, 'usage': 'internal'},
            'wh_input_stock_loc_id': {'name': _('Input'), 'active': reception_steps != 'one_step', 'usage': 'internal'},
            'wh_qc_stock_loc_id': {'name': _('Quality Control'), 'active': reception_steps == 'three_steps', 'usage': 'internal'},
            'wh_output_stock_loc_id': {'name': _('Output'), 'active': delivery_steps != 'ship_only', 'usage': 'internal'},
            'wh_pack_stock_loc_id': {'name': _('Packing Zone'), 'active': delivery_steps == 'pick_pack_ship', 'usage': 'internal'},
        }
        for field_name, values in sub_locations.items():
            values['location_id'] = vals['view_location_id']
            if vals.get('company_id'):
                values['company_id'] = vals.get('company_id')
            vals[field_name] = self.env['stock.location'].with_context(active_test=False).create(values).id

        # actually create WH
        warehouse = super(warehouse_inherit, self).create(vals)
        # create sequences and operation types
        new_vals = warehouse.create_sequences_and_picking_types()
        warehouse.write(new_vals)  # TDE FIXME: use super ?
        # create routes and push/procurement rules
        route_vals = warehouse.create_routes()
        warehouse.write(route_vals)
        # update partner data if partner assigned
        if vals.get('partner_id'):
            self._update_partner_data(vals['partner_id'], vals.get('company_id'))
        return warehouse



# -*- coding: utf-8 -*-

from odoo import models, fields, api ,_
from odoo.exceptions import UserError



class customer_state_mod(models.Model):
    _name = 'customer.state_mod'
    _rec_name = 'name'

    name = fields.Char(string="State")
    description = fields.Text(string="Description")



class partner_template_inherit(models.Model):
    _inherit = 'res.partner'


    currency_id = fields.Many2one('res.currency', string='Currency', required=True, default=lambda self: self.env.user.company_id.currency_id)
    code = fields.Char(string="Number", readonly=True)
    customer_state =fields.Many2one(comodel_name='customer.state_mod' , string="Customer State" , required=False)
    procedures = fields.Text(string="Customer Procedures")
    commercial_activity = fields.Text(string="Commercial Activity")
    opening_balance = fields.Monetary(string="Opening Balance")
    credit_limit= fields.Monetary(string="Credit Limit")
    discount_type = fields.Selection([('percentage', 'Percentage'), ('amount', 'Amount'), ('product', 'Product')], string="Discount Type")
    percentage_discount = fields.Float(string="Percentage Discount")
    amount_discount = fields.Monetary(string="Amount Discount")
    product_discount = fields.Many2one(comodel_name='product.template',string="Product Discount")
    sector = fields.Many2one(comodel_name='sector.sector' , string="Sector")
    zone = fields.Many2one(comodel_name='zone.zone' , string="Zone" )
    district = fields.Many2one(comodel_name='district.district' , string="District" )



    @api.onchange('sector')
    def onchange_sector(self):
        if self.name:
            return {'domain': {'zone': [('sector', '=', self.sector.id)]}}

    @api.onchange('name')
    def onchange_name(self):
        self.sector = False
        self.zone = False
        self.district = False


    @api.onchange('zone' )
    def onchange_zone(self):
        if self.name:
            if not self.sector:
                raise UserError("Please Choose The Sector First Then The Zone .")
            else:
                return {'domain': {'district': [('zone', '=', self.zone.id),('sector', '=', self.sector.id)]}}

    @api.onchange('district' )
    def onchange_district(self):
        if self.name:
            if not self.sector:
                raise UserError("Please Choose The Sector First Then The Zone .")
            elif not self.zone:
                raise UserError("Please Choose The Zone First Then The District .")


    @api.model
    def create(self, vals):
        if vals['customer']:
            vals['code'] = self.env['ir.sequence'].next_by_code('customer.res.partner.seq')
        elif vals['supplier']:
            vals['code'] = self.env['ir.sequence'].next_by_code('vendor.res.partner.seq')

        return super(partner_template_inherit, self).create(vals)